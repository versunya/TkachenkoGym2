//
//  SingInViewController.swift
//  Tkachenko Gym
//
//  Created by WSR on 01.02.2021.
//

import UIKit
import Alamofire
import SwiftyJSON

class SingInViewController: UIViewController {

    @IBOutlet weak var inputLogin: UITextField!
    @IBOutlet weak var inputPassword: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func signInAction(_ sender: UIButton) {
        let url = "http://gym.areas.su/signin?username=\(inputLogin.text!) && password=\(inputPassword.text!)"
        
        AF.request(url, method: .post).responseJSON { response in
            switch response.result {
            case .success(let value):
                let json = JSON(value)
                let token: Int?
                print(value)
                token = json["notice"]["token"].intValue
                if token! > 0 {
                    print(token)
                } else {
                    self.alertShow(message: String(token!))
                }
            case .failure(let error):
                self.alertShow(message: error.localizedDescription)
            }
        }
    }
    
    func alertShow(message: String) {
        let alert = UIAlertController(title: "Уведомление", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "ОК", style: .default, handler: nil))
        present(alert, animated: true, completion: nil)
    }
    

    @IBAction func ButtonSingUpAction(_ sender: UIButton) {
        self.performSegue(withIdentifier: "GoSingUp", sender: nil)
    }
    
}
   
