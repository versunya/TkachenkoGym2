//
//  SingUpViewController.swift
//  Tkachenko Gym
//
//  Created by WSR on 03.02.2021.
//

import UIKit
import Alamofire
import SwiftyJSON

class SingUpViewController: UIViewController {

    
    @IBOutlet weak var buttonBack: UIButton!
    @IBOutlet weak var inputLogin: UITextField!
    @IBOutlet weak var inputEmail: UITextField!
    @IBOutlet weak var inputPassword: UITextField!
    @IBOutlet weak var inputRepassword: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        view.alpha = 0.0
    }
    
    override func viewDidAppear(_ animated: Bool) {
        UIView.animate(withDuration: 1.0) {
            self.view.alpha = 1.0
        }
    }

    func checkValidatePassword() -> Bool {
        if inputPassword.text == inputRepassword.text {
            print("Password checked")
            return true
        } else {
            return false
        }
    }
    
    func checkEmail() -> Bool {
        let emailFormat = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,5}"
                let emailPredicate = NSPredicate(format:"SELF MATCHES %@", emailFormat)
                return emailPredicate.evaluate(with: self)
    }

    @IBAction func buttonSingupAction(_ sender: UIButton) {
        guard inputPassword.text?.isEmpty == false else {return print("Empty!")}
        guard checkValidatePassword() else { return }
        
        guard inputLogin.text?.isEmpty == false else {return print("Empty!")}
        
        guard inputEmail.text?.isEmpty == false else {return print("Empty!")}
        
        guard checkEmail() else {return}
        
        
        let url = "http://gym.areas.su/signup?username=\(inputLogin.text!) && password=\(inputPassword.text!) && email=\(inputEmail.text!) && height=\(height) && weight=\(weight)"
        AF.request(url, method: .post).responseJSON { response in
           switch response.result {
           case .success(let value):
               let json = JSON(value)
               let token: Int?
               print(value)
               token = json["notice"]["token"].intValue
               if token! > 0 {
                   print(token)
               } else {
                   self.alertShow(message: String(token!))
               }
           case .failure(let error):
               self.alertShow(message: error.localizedDescription)
           }
            
        }
        
        print("OK")
    }
    func alertShow(message: String) {
        let alert = UIAlertController(title: "Уведомление", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "ОК", style: .default, handler: nil))
        present(alert, animated: true, completion: nil)
    }
    
}



