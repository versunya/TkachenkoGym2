//
//  UserBody.swift
//  Tkachenko Gym
//
//  Created by WSR on 29.01.2021.
//

import Foundation

var height: Double = 0
var weight: Double = 0
